<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_873330fc1881555fffe2bc471d04bf5d'] = 'Bloc réassurance';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_7e7f70db3c75e428db8e2d0a1765c4e9'] = 'Ajoute un bloc pour afficher des informations pour rassurer vos clients';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_d52eaeff31af37a4a7e0550008aff5df'] = 'Une erreur est survenue lors de la sauvegarde';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_0366c7b2ea1bb228cd44aec7e3e26a3e'] = 'Configuration mise à jour';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_8363eee01f4da190a4cef9d26a36750c'] = 'Nouveau bloc de réassurance';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_be53a0541a6d36f6ecb879fa2c584b08'] = 'Image';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Texte';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_630f6dc397fe74e52d5189e2c80f282b'] = 'Retour à la liste';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_23498d91b6017e5d7f4ddde70daba286'] = 'ID de la boutique';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_ef61fb324d729c341ea8ab9901e23566'] = 'Ajouter';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_f3295a93167b56c5a19030e91823f7bf'] = 'Satisfait ou remboursé';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_56e140ebd6f399c22c8859a694b247f3'] = 'Échange en magasin';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_597ce11744f9bbf116ec9e4a719ec9d3'] = 'Paiement à l\'expédition.';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_3aca7ac5cf7e462b658960931946f824'] = 'Livraison gratuite';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_d05244e0e410a6b85ed53a014908c657'] = 'Paiement 100% sécurisé';


return $_MODULE;

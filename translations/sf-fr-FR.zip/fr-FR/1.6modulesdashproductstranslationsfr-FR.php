<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashproducts}prestashop>dashproducts_6655df4af87b2038afd507a33545a56d'] = 'Tableau de bord Produits';
$_MODULE['<{dashproducts}prestashop>dashproducts_4a528e24be5aca96e8a15b256efe1f31'] = 'Ajoute un bloc avec un tableau de vos dernières commandes et le classement de vos meilleurs produits';
$_MODULE['<{dashproducts}prestashop>dashproducts_2ea989f83006e233627987293f4bde0a'] = 'Nom du client';
$_MODULE['<{dashproducts}prestashop>dashproducts_068f80c7519d0528fb08e82137a72131'] = 'Produits';
$_MODULE['<{dashproducts}prestashop>dashproducts_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_MODULE['<{dashproducts}prestashop>dashproducts_58ef6750a23ba432fc1377b7de085d9f'] = 'HT';
$_MODULE['<{dashproducts}prestashop>dashproducts_44749712dbec183e983dcd78a7736c41'] = 'Date';
$_MODULE['<{dashproducts}prestashop>dashproducts_ec53a8c4f07baed5d8825072c89799be'] = 'État';
$_MODULE['<{dashproducts}prestashop>dashproducts_3ec365dd533ddb7ef3d1c111186ce872'] = 'Détails';
$_MODULE['<{dashproducts}prestashop>dashproducts_be53a0541a6d36f6ecb879fa2c584b08'] = 'Image';
$_MODULE['<{dashproducts}prestashop>dashproducts_deb10517653c255364175796ace3553f'] = 'Produit';
$_MODULE['<{dashproducts}prestashop>dashproducts_3adbdb3ac060038aa0e6e6c138ef9873'] = 'Catégorie';
$_MODULE['<{dashproducts}prestashop>dashproducts_2aed3d711270a6ed67d21ec2d7cd4af8'] = 'Total vendu';
$_MODULE['<{dashproducts}prestashop>dashproducts_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventes';
$_MODULE['<{dashproducts}prestashop>dashproducts_9e79098315622e58529d664b9a8b3cf8'] = 'Bénéfice net';
$_MODULE['<{dashproducts}prestashop>dashproducts_ed4832a84ee072b00a6740f657183598'] = 'Vues';
$_MODULE['<{dashproducts}prestashop>dashproducts_2c04f1ad7694378897b98624780327ff'] = 'Ajoutés au panier';
$_MODULE['<{dashproducts}prestashop>dashproducts_ce4ee01637f4279d02d0f232459dc9a4'] = 'Achetés';
$_MODULE['<{dashproducts}prestashop>dashproducts_37be07209f53a5d636d5c904ca9ae64c'] = 'Pourcentage';
$_MODULE['<{dashproducts}prestashop>dashproducts_1eb18ea1d018abef5759cef60ddc289b'] = 'Vous devez activer l\'option "Enregistrer les pages vues pour chaque client" du module "Récupération des données statistiques" afin d\'afficher les produits les plus vus, ou utiliser le module Google Analytics.';
$_MODULE['<{dashproducts}prestashop>dashproducts_cf5f3091e30dee6597885d8c0e0c357f'] = 'Terme';
$_MODULE['<{dashproducts}prestashop>dashproducts_13348442cc6a27032d2b4aa28b75a5d3'] = 'Rechercher';
$_MODULE['<{dashproducts}prestashop>dashproducts_fd69c5cf902969e6fb71d043085ddee6'] = 'Résultats';
$_MODULE['<{dashproducts}prestashop>dashproducts_38fb7d24e0d60a048f540ecb18e13376'] = 'Enregistrer';
$_MODULE['<{dashproducts}prestashop>dashproducts_ea4788705e6873b424c65e91c2846b19'] = 'Annuler';
$_MODULE['<{dashproducts}prestashop>dashproducts_85bf7474324d7d02725e4dca586afcd9'] = 'Nombre de "Commandes récentes" à afficher';
$_MODULE['<{dashproducts}prestashop>dashproducts_735b8c7f6d50b4c6f818deeab3cdea4a'] = 'Nombre de "Meilleures ventes" à afficher';
$_MODULE['<{dashproducts}prestashop>dashproducts_14d24dddc4c67abf8364b980b2ccd5a2'] = 'Nombre de "Produits les plus vus" à afficher';
$_MODULE['<{dashproducts}prestashop>dashproducts_f1ee1eaab342241138d45f35f4d8466a'] = 'Nombre de "Meilleures recherches" à afficher';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_3e361ce73ecabd6524af286d55809ed7'] = 'Produits et Ventes';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'Configurer';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'Rafraîchir';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_254f642527b45bc260048e30704edb39'] = 'Paramètres';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_fd3458547ef9c3a8bd0e1e1b4ef2b4dd'] = 'Commandes récentes';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_d7b2933ba512ada478c97fa43dd7ebe6'] = 'Meilleures Ventes';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_be5006eb5af9ab6dbca803f8d3065bbc'] = 'plus vus';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_1eb5e5713d7363e921dd7f5500b6d212'] = 'Meilleures recherches';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_3d23ac9ab254a9f1014c3a859b01bcfc'] = '%d dernières commandes';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_82f0f8d535196ce2a6ea16652d981f94'] = '%d meilleurs produits';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_5da618e8e4b89c66fe86e32cdafde142'] = 'Du';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_01b6e20344b68835c5ed1ddedf20d531'] = 'jusqu\'au';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_1daaca459ce1e6610e0b97a9ad723f27'] = '%d mots les plus recherchés';


return $_MODULE;

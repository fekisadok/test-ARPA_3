<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashtrends}prestashop>dashtrends_ee653ade5f520037ef95e9dc2a42364c'] = 'Tableau de bord des tendances';
$_MODULE['<{dashtrends}prestashop>dashtrends_f2d0efa68eb71bfd5209abeb9f4b0943'] = 'Ajoute à votre tableau de bord un graphique représentant l\'évolution des indicateurs clés de votre boutique.';
$_MODULE['<{dashtrends}prestashop>dashtrends_2d125dc25b158f28a1960bd96a9fa8d1'] = '%s points';
$_MODULE['<{dashtrends}prestashop>dashtrends_887ee91702c962a70b87cbef07bbcaec'] = 'HT';
$_MODULE['<{dashtrends}prestashop>dashtrends_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventes';
$_MODULE['<{dashtrends}prestashop>dashtrends_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Commandes';
$_MODULE['<{dashtrends}prestashop>dashtrends_8c804960da61b637c548c951652b0cac'] = 'Panier moyen';
$_MODULE['<{dashtrends}prestashop>dashtrends_d7e637a6e9ff116de2fa89551240a94d'] = 'Visites';
$_MODULE['<{dashtrends}prestashop>dashtrends_e4c3da18c66c0147144767efeb59198f'] = 'Taux de transformation';
$_MODULE['<{dashtrends}prestashop>dashtrends_43d729c7b81bfa5fc10e756660d877d1'] = 'Bénéfice net';
$_MODULE['<{dashtrends}prestashop>dashtrends_46418a037045b91e6715c4da91a2a269'] = '%s (période précédente)';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_2938c7f7e560ed972f8a4f68e80ff834'] = 'Tableau de bord';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'Configurer';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'Rafraîchir';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_e537825dd409a90ef70d8c2eb56122a1'] = 'Chiffre d\'affaires (HT) généré sur la période donnée par les commandes considérées comme validées.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventes';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_8bc1c5ca521b99b87908db0bcd33ec76'] = 'Nombre total de commandes passées dans l\'intervalle de dates et considérées comme validées.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Commandes';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_f15f2a2bf99d3dcad2cba1a2c615b9dc'] = 'Le Panier Moyen est une mesure représentant la valeur de la commande moyenne sur la période. Elle est calculée en divisant le montant global des ventes par le nombre de commandes.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_791d6355d34dfaf60d68ef04d1ee5767'] = 'Panier Moyen';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_4f631447981c5fa240006a5ae2c4b267'] = 'Nombre total de visites dans l\'intervalle de dates. Une visite est la durée pendant laquelle un utilisateur est actif sur votre site.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_d7e637a6e9ff116de2fa89551240a94d'] = 'Visites';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_7a6e858f8c7c0b78fb4d43cefcb8c017'] = 'Le taux de conversion e-commerce est le pourcentage de visites ayant abouti à une commande validée.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_e4c3da18c66c0147144767efeb59198f'] = 'Taux de transformation';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_8dedc1b3ee3a92212fb5b5acad7f207f'] = 'Le bénéfice est une mesure de la profitabilité de votre entreprise après déduction de tous les frais de gestion. Vous pouvez renseigner ces coûts en cliquant sur l\'icône de configuration ci-dessus.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_43d729c7b81bfa5fc10e756660d877d1'] = 'Bénéfice net';


return $_MODULE;

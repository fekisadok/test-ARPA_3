<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{followup}prestashop>followup_9c34e90380dac7b56fdd19192a99d531'] = 'Relancez vos clients';
$_MODULE['<{followup}prestashop>followup_57476355fcd04050bff196ae9aa4673c'] = 'Relancez vos clients grâce à des envoi d\'e-mails quotidiens';
$_MODULE['<{followup}prestashop>followup_f71a41841c80c2ef0ec02a6ad5449c65'] = 'Etes-vous sûr de vouloir supprimer vos paramètres ainsi que vos statistiques liées aux relances ?';
$_MODULE['<{followup}prestashop>followup_e316b4398212d473f7f53c7728fe1c37'] = 'Paramètres mis à jour avec succès';
$_MODULE['<{followup}prestashop>followup_003b06dcfe67596f17e3de26e6a436c8'] = 'Une erreur est survenue pendant la mise à jour des paramètres';
$_MODULE['<{followup}prestashop>followup_edf9feeab43a7623f6afc152d1ede515'] = 'Bon de réduction pour votre panier abandonné';
$_MODULE['<{followup}prestashop>followup_a053fc9952a7dfc79282eba56ab8ad3a'] = 'Merci pour votre commande';
$_MODULE['<{followup}prestashop>followup_7fcd592dd47028c7c1f2d0ce9168a303'] = 'Vous êtes l\'un de nos meilleurs clients';
$_MODULE['<{followup}prestashop>followup_c2ab23672d4bb31c7664bf8e854a10f7'] = 'Vous nous manquez';
$_MODULE['<{followup}prestashop>followup_fba6524bb4f34a4c7d8e84b082fc4ce1'] = 'Effectuez vos réglages et ajoutez cette URL à votre crontab, ou appelez-la manuellement chaque jour :';
$_MODULE['<{followup}prestashop>followup_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Informations';
$_MODULE['<{followup}prestashop>followup_87b1e57b5e8cd700618b6ae4938a4023'] = 'Quatre types de relances afin de rester en contact avec vos clients !';
$_MODULE['<{followup}prestashop>followup_b547c073d144a57761d1d00d0b9d9f27'] = 'Paniers annulés';
$_MODULE['<{followup}prestashop>followup_ea9dc62a0ddf4640f019f04a22ab9835'] = 'Pour chaque panier abandonné (sans commande), génère un bon d\'achat et l\'envoie au client.';
$_MODULE['<{followup}prestashop>followup_2faec1f9f8cc7f8f40d521c4dd574f49'] = 'Activer';
$_MODULE['<{followup}prestashop>followup_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{followup}prestashop>followup_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{followup}prestashop>followup_b30690be173bcd4a83df0cd68f89a385'] = 'Montant de la remise';
$_MODULE['<{followup}prestashop>followup_2018945d252b94aeb99b0909f288717c'] = 'Durée de validité';
$_MODULE['<{followup}prestashop>followup_225e75c29d32392d311f5dc94c792384'] = 'jour(s)';
$_MODULE['<{followup}prestashop>followup_4c5caf3567f8b9ce900fe5973453b68c'] = 'Le prochain processus enverra %d e-mail(s).';
$_MODULE['<{followup}prestashop>followup_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{followup}prestashop>followup_a8b8dbd070a92fb8b17baab71d8d633f'] = 'Re-commander';
$_MODULE['<{followup}prestashop>followup_895858cf10b8a1750a42875cb9c69092'] = 'Pour chaque commande validée, génère un bon d\'achat et l\'envoie au client.';
$_MODULE['<{followup}prestashop>followup_f120254f109d626d73ddddeb9cda26e5'] = 'Le prochain envoi transmettra : %d e-mail(s)';
$_MODULE['<{followup}prestashop>followup_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Meilleurs clients';
$_MODULE['<{followup}prestashop>followup_a46ad892f7f00e051cc90050ff2e1ddf'] = 'Pour chaque client dont le total des commandes atteint un certain seuil, génère un bon d\'achat et l\'envoie au client.';
$_MODULE['<{followup}prestashop>followup_2a63f555989152ba866b43a1faacd680'] = 'Seuil';
$_MODULE['<{followup}prestashop>followup_7d75b7b0f976b3091f490864c6ffbf97'] = 'Mauvais clients';
$_MODULE['<{followup}prestashop>followup_346f38f5b951daec00dcca38364f8359'] = 'Pour chaque client ayant déjà passé au moins une commande et sans commande depuis un certain temps, génère un bon d\'achat et l\'envoie au client.';
$_MODULE['<{followup}prestashop>followup_d82843c16839bfb05827d1912d89c917'] = 'Depuis x jours';
$_MODULE['<{followup}prestashop>followup_0db377921f4ce762c62526131097968f'] = 'Paramètres généraux';
$_MODULE['<{followup}prestashop>followup_1d52a8fe6cab6930fad9d814a1b0ca4c'] = 'Supprimer les bons d\'achat dont la date d\'expiration est dépassée afin de nettoyer la base de données';
$_MODULE['<{followup}prestashop>stats_c33e404a441c6ba9648f88af3c68a1ca'] = 'Statistiques';
$_MODULE['<{followup}prestashop>stats_dfc7d0b719158a75e0d324cc74f3185e'] = 'Statistiques détaillées sur les 30 derniers jours :';
$_MODULE['<{followup}prestashop>stats_d41455f28486975bfab163b66a473502'] = 'Envoyés : nombre d\'e-mails envoyés';
$_MODULE['<{followup}prestashop>stats_4b416f06e3eea5059973acaa8325c8fa'] = 'Utilisées : nombre de réductions utilisées (uniquement les commandes validées)';
$_MODULE['<{followup}prestashop>stats_3c4d61c4fbde6177beb0f337711bde6c'] = 'Conversion (%) = taux de conversion';
$_MODULE['<{followup}prestashop>stats_44749712dbec183e983dcd78a7736c41'] = 'Date';
$_MODULE['<{followup}prestashop>stats_4a43635068b63d16d845f9feb6bcc125'] = 'Paniers annulés';
$_MODULE['<{followup}prestashop>stats_c336ea796ae42ed04ed1ac310a678823'] = 'Nouvelles commandes';
$_MODULE['<{followup}prestashop>stats_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Meilleurs clients';
$_MODULE['<{followup}prestashop>stats_7d75b7b0f976b3091f490864c6ffbf97'] = 'Mauvais clients';
$_MODULE['<{followup}prestashop>stats_7f8c0283f16925caed8e632086b81b9c'] = 'Envoyés';
$_MODULE['<{followup}prestashop>stats_019d1ca7d50cc54b995f60d456435e87'] = 'Utilisé';
$_MODULE['<{followup}prestashop>stats_476d1393bbe84d62f25e2ce2ec3cd61c'] = 'Conversion (%)';
$_MODULE['<{followup}prestashop>stats_85b6769250887ba6c16099596c75164d'] = 'Aucune statistique à l\'heure actuelle.';


return $_MODULE;

<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{ganalytics}prestashop>ganalytics_d86cf69a8b82547a94ca3f6a307cf9a6'] = 'Google Analytics';
$_MODULE['<{ganalytics}prestashop>ganalytics_135d2522825fa02688ab25a2e1c88c73'] = 'Gagnez en visibilité sur des indicateurs clés liés à vos clients en utilisant Google Analytics.';
$_MODULE['<{ganalytics}prestashop>ganalytics_7ed5c154078e30b30b2f214299c5e9f5'] = 'Êtes-vous sûr de vouloir désinstaller Google Analytics ? Vous perdrez toutes les données relatives à ce module.';
$_MODULE['<{ganalytics}prestashop>ganalytics_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{ganalytics}prestashop>ganalytics_630f6dc397fe74e52d5189e2c80f282b'] = 'Retour à la liste';
$_MODULE['<{ganalytics}prestashop>ganalytics_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{ganalytics}prestashop>ganalytics_851bd83a102d143ee17d97f9e15e15af'] = 'ID de tracking Google Analytics';
$_MODULE['<{ganalytics}prestashop>ganalytics_ad8e83a47926dcb12e8a8fccd7fcf604'] = 'Vous trouverez cette information dans votre compte Google Analytics';
$_MODULE['<{ganalytics}prestashop>ganalytics_bcd08e73ca9d8bfed2cccd50dd6d8328'] = 'Activer la fonctionnalité "User-ID"';
$_MODULE['<{ganalytics}prestashop>ganalytics_9bda6a2c3edca377eb901d7ea57c8b06'] = 'Le "User-ID" est paramétré au niveau de la propriété. Pour trouver une propriété, cliquez sur "Admin", puis sélectionnez un compte et une propriété. Dans la colonne "Propriété", cliquez sur "Informations de suivi" puis "User ID"';
$_MODULE['<{ganalytics}prestashop>ganalytics_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{ganalytics}prestashop>ganalytics_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{ganalytics}prestashop>ganalytics_612e1a524ec979815b12182c34e2daa0'] = 'Votre identifiant de tracking a bien été mis à jour';
$_MODULE['<{ganalytics}prestashop>ganalytics_8e7b67b44506b7ac6685da041a603044'] = 'Les paramètres de la fonctionnalité "User-ID" ont bien été mis à jour';
$_MODULE['<{ganalytics}prestashop>configuration_1f13d86a35be758509f9bdfcce5ec55d'] = 'Vos clients vont partout : vos analyses doivent pouvoir les suivre.';
$_MODULE['<{ganalytics}prestashop>configuration_7063e771c3bb338ba74ac4e4716dbae1'] = 'Google Analytics brosse un portrait détaillé de vos clients à travers leur utilisation de publicités, vidéos, sites, outils sociaux, tablettes et smartphones. Cela vous permet de mieux répondre à vos clients actuels et d\'en gagner de nouveaux.';
$_MODULE['<{ganalytics}prestashop>configuration_df15c5cf264eb769b087f9d81aff029f'] = 'Avec la fonctionnalité e-commerce de Google Analytics, vous pouvez affiner vos analyses grâce à des indicateurs clés sur le comportement d\'achat et de conversion, comme :';
$_MODULE['<{ganalytics}prestashop>configuration_613c191b4a1f82a454b72a840d96eefd'] = 'L\'affichage des détails du produit';
$_MODULE['<{ganalytics}prestashop>configuration_d88b192dfe623e2a628a919b99fc1a4b'] = 'La performance de votre merchandising';
$_MODULE['<{ganalytics}prestashop>configuration_ade6a18bb6c147db87bc9463240e455a'] = 'Les actions d\'ajout au panier';
$_MODULE['<{ganalytics}prestashop>configuration_c975b6b93d71b19da73114c4adcedbda'] = 'Le processus de commande';
$_MODULE['<{ganalytics}prestashop>configuration_33f50b54625790316b86485ff3e794c4'] = 'Le clics de campagne interne';
$_MODULE['<{ganalytics}prestashop>configuration_89c48ff165eedcc3cd1bd0007115669d'] = 'et l\'achat';
$_MODULE['<{ganalytics}prestashop>configuration_4632d86a96205013262bcfdd0279b39f'] = 'Vous pourrez comprendre jusqu\'où les utilisateurs vont dans le processus d\'achat, et où ils l\'abandonnent.';
$_MODULE['<{ganalytics}prestashop>configuration_16fafb5cce24f766bf2c8fcebecf76fc'] = 'Créez votre compte pour démarrer';
$_MODULE['<{ganalytics}prestashop>form-ps14_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';


return $_MODULE;

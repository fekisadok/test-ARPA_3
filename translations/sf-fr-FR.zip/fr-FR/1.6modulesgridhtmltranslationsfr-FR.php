<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{gridhtml}prestashop>gridhtml_cf6b972204ee563b4e5691b293e931b6'] = 'Affichage HTML simple';
$_MODULE['<{gridhtml}prestashop>gridhtml_05ce5a49b49dd6245f71e384c4b43564'] = 'Permet au système de statistiques d\'afficher ses données dans une grille.';


return $_MODULE;

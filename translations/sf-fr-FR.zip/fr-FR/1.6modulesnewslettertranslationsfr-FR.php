<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{newsletter}prestashop>newsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'Lettre d\'informations';
$_MODULE['<{newsletter}prestashop>newsletter_804a924e464fd21ed92f820224c4091d'] = 'Génère un fichier .CSV pour vos envois d\'e-mails';
$_MODULE['<{newsletter}prestashop>newsletter_c3987e4cac14a8456515f0d200da04ee'] = 'Tous les pays';
$_MODULE['<{newsletter}prestashop>newsletter_fa01fd956e87307bce4c90a0de9b0437'] = 'Pays du client';
$_MODULE['<{newsletter}prestashop>newsletter_7599b57d77ef1608b2f6da579794cc5b'] = 'Filtre les clients par pays.';
$_MODULE['<{newsletter}prestashop>newsletter_2198f293f5e1e95dddeff819fbca0975'] = 'Abonnés newsletter';
$_MODULE['<{newsletter}prestashop>newsletter_99006a61d48499231e1be92241cf772a'] = 'Opérer un filtre sur les abonnés à la lettre d\'information.';
$_MODULE['<{newsletter}prestashop>newsletter_7e3a51a56ddd2846e21c33f05e0aea6f'] = 'Tous les clients';
$_MODULE['<{newsletter}prestashop>newsletter_39f7a3e2b56e9bfd753ba6325533a127'] = 'Abonnés';
$_MODULE['<{newsletter}prestashop>newsletter_011d8c5d94f729f013963d856cd78745'] = 'Non-abonnés';
$_MODULE['<{newsletter}prestashop>newsletter_6395c19dc5a1cef9ca125b9736358dc7'] = 'Abonnés aux partenaires';
$_MODULE['<{newsletter}prestashop>newsletter_3136b84457870341f29f741f7a07d325'] = 'Filtre les abonnés aux offres partenaires.';
$_MODULE['<{newsletter}prestashop>newsletter_82e5e0bc0f9c776c98253d569c111c0f'] = 'Aucun client trouvé avec ces paramètres';
$_MODULE['<{newsletter}prestashop>newsletter_644ecc2486a059ca16b001a77909bf40'] = 'Le fichier .CSV a bien été exporté : %d clients trouvés.';
$_MODULE['<{newsletter}prestashop>newsletter_48e3d5f66961b621c78f709afcd7d437'] = 'Télécharger le fichier';
$_MODULE['<{newsletter}prestashop>newsletter_dca37b874cf34bd5ebcf1c2fdc59a8b4'] = 'ATTENTION : Lorsque vous ouvrez ce fichier .csv avec Excel, choisissez bien l\'encodage UTF-8 pour éviter les caractères anormaux.';
$_MODULE['<{newsletter}prestashop>newsletter_b40866b115d74009183e06fc86b5c014'] = 'Erreur : droits d\'écriture limités';
$_MODULE['<{newsletter}prestashop>newsletter_81573e0ea79138f02fd2cee94786d7e9'] = 'Erreur : impossible d\'écrire vers';
$_MODULE['<{newsletter}prestashop>newsletter_73059f9530a1a37563150df4dea4bb70'] = 'Tous les abonnés';
$_MODULE['<{newsletter}prestashop>newsletter_a307579714b75082f3f8734971b125cd'] = 'Abonnés avec un compte';
$_MODULE['<{newsletter}prestashop>newsletter_d0da5609e4aebc5d532de97511a5a34a'] = 'Abonnés sans compte';
$_MODULE['<{newsletter}prestashop>newsletter_4713ef5f2d6fc1e8f088c850e696a04b'] = 'Export des clients';
$_MODULE['<{newsletter}prestashop>newsletter_dbb392a2dc9b38722e69f6032faea73e'] = 'Exporte un fichier CSV';


return $_MODULE;

<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_4f29d8c727dcf2022ac241cb96c31083'] = 'Aucun résultat renvoyé';
$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_f5c493141bb4b2508c5938fd9353291a'] = 'Affichage de %1$s de %2$s';
$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_eebfd2d9a7ea25b9e61e8260bcd4849c'] = 'Quantité totale vendue';
$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_f3547ae5e06426d87312eff7dda775aa'] = 'Prix total vendu';
$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_89a4e26859399438513f41c4971795b5'] = 'Marge';
$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_c13329e42ec01a10f84c0f950274b404'] = 'Total consulté';
$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_6e3b3150807da868ebd33ad2c991b8d7'] = 'Meilleures catégories';
$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_e5510869e31bbf721ca15dff21cf1169'] = 'Ajoute une liste des meilleures catégories dans le tableau de bord des statistiques.';
$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statsbestcategories}prestashop>statsbestcategories_26f1502c886f4daa37c43d27bb58d40d'] = 'Afficher uniquement les catégories de dernier niveau (qui n\'ont pas de sous-catégories)';


return $_MODULE;

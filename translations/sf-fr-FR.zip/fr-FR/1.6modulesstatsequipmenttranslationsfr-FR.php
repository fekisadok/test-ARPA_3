<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsequipment}prestashop>statsequipment_247270d410e2b9de01814b82111becda'] = 'Navigateurs web et systèmes d\'exploitation';
$_MODULE['<{statsequipment}prestashop>statsequipment_2876718a648dea03aaafd4b5a63b1efe'] = 'Ajoute un onglet contenant un graphique des navigateurs web et systèmes d\'exploitation utilisé, dans le tableau de bord des statistiques.';
$_MODULE['<{statsequipment}prestashop>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsequipment}prestashop>statsequipment_854c8e126f839cc861cde822b641230e'] = 'S\'assurer que votre site web est accessible au plus grand nombre de personnes possible';
$_MODULE['<{statsequipment}prestashop>statsequipment_0d5f13106dec10bb8a9301541052278c'] = 'Lorsque l\'on gère un site Web, il est important de garder une trace des logiciels utilisés par les visiteurs afin d\'être sûr que le site s\'affiche de la même façon pour tout le monde. PrestaShop a été conçu pour être compatible avec les navigateurs Web et les systèmes d\'exploitation (OS) les plus récents. Cependant, dans le cas où vous auriez ajouté des fonctionnalités avancées à votre site web ou même modifié le code de base de PrestaShop, ces ajouts peuvent ne pas être accessibles à tous. C\'est pourquoi il faut garder un œil sur le pourcentage d\'utilisateurs pour chaque type de logiciel avant d\'ajouter ou changer quelque chose auquel seul un nombre limité d\'utilisateurs pourront accéder.';
$_MODULE['<{statsequipment}prestashop>statsequipment_11db1362a88c5e3e74c8f699c14d6798'] = 'Indique la popularité de chaque navigateur, en pourcentage d\'utilisation sur la base de vos clients.';
$_MODULE['<{statsequipment}prestashop>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statsequipment}prestashop>statsequipment_90c58bfe4872fc9ca7bf6a181c3e5edd'] = 'Indique le pourcentage de chaque système d\'exploitation utilisé par les clients.';
$_MODULE['<{statsequipment}prestashop>statsequipment_bb38096ab39160dc20d44f3ea6b44507'] = 'Extensions';
$_MODULE['<{statsequipment}prestashop>statsequipment_9ffafc9e090c8e1c06f928ef2817efd6'] = 'Navigateurs utilisés';
$_MODULE['<{statsequipment}prestashop>statsequipment_0241b7aaaa5f76afd585bb6cdae314d1'] = 'Systèmes d\'exploitation utilisés';


return $_MODULE;

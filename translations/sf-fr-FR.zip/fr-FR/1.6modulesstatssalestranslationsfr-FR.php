<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statssales}prestashop>statssales_45c4b3e103155326596d6ccd2fea0f25'] = 'Commandes et CA';
$_MODULE['<{statssales}prestashop>statssales_d2fb07753354576172a2b144c373a610'] = 'Ajoute des graphiques présentant l\'évolution des ventes et des commandes sur le tableau de bord des statistiques.';
$_MODULE['<{statssales}prestashop>statssales_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statssales}prestashop>statssales_bdaa0cab56c2880f8f60e6a2cef40e63'] = 'À propos des états de commandes';
$_MODULE['<{statssales}prestashop>statssales_fdfa8599f3887bef99e9572f3611260f'] = 'Au sein de votre back-office, plusieurs états de commande sont disponibles : En attente du paiement par chèque, Paiement accepté, Préparation en cours, En cours de livraison, Livré, Annulé, Remboursé, Erreur de paiement, Rupture de stock et En attente du paiement par virement bancaire.';
$_MODULE['<{statssales}prestashop>statssales_4b75384caa4e6830c22f15e06e0bfac0'] = 'Ces états ne peuvent être supprimés depuis le back-office, cependant vous pouvez en ajouter de nouveaux.';
$_MODULE['<{statssales}prestashop>statssales_ddb21e1caa84c463bc744c412a7b05f5'] = 'Les graphiques suivants représentent l\'évolution des commandes et du chiffre d\'affaires de votre boutique sur une période donnée.';
$_MODULE['<{statssales}prestashop>statssales_ef9c3c65723819a9c183d857a39ff403'] = 'Vous devriez souvent consulter cette page car elle vous permet d\'évaluer rapidement la viabilité de votre boutique, et ce sur plusieurs périodes données.';
$_MODULE['<{statssales}prestashop>statssales_5cc6f5194e3ef633bcab4869d79eeefa'] = 'Seules les commandes valides sont représentées sur le graphique.';
$_MODULE['<{statssales}prestashop>statssales_c3987e4cac14a8456515f0d200da04ee'] = 'Tous les pays';
$_MODULE['<{statssales}prestashop>statssales_d7778d0c64b6ba21494c97f77a66885a'] = 'Filtrer';
$_MODULE['<{statssales}prestashop>statssales_9ccb8353e945f1389a9585e7f21b5a0d'] = 'Commandes passées :';
$_MODULE['<{statssales}prestashop>statssales_156e5c5872c9af24a5c982da07a883c2'] = 'Produits commandés :';
$_MODULE['<{statssales}prestashop>statssales_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statssales}prestashop>statssales_ec3e48bb9aa902ba2ad608547fdcbfdc'] = 'Ventes :';
$_MODULE['<{statssales}prestashop>statssales_f6825178a5fef0a97dacf963409829f0'] = 'Vous pouvez voir la distribution des états de commandes ci-dessous.';
$_MODULE['<{statssales}prestashop>statssales_da80af4de99df74dd59e665adf1fac8f'] = 'Aucune commande pour cette période';
$_MODULE['<{statssales}prestashop>statssales_c58114720bcd52bfe96fd801cee77e93'] = 'Commandes passées';
$_MODULE['<{statssales}prestashop>statssales_c8be451a5698956a0e78b5c2caab4821'] = 'Produits commandés';
$_MODULE['<{statssales}prestashop>statssales_b52b44c9d23e141b067d7e83b44bb556'] = 'Produits :';
$_MODULE['<{statssales}prestashop>statssales_497a2a4cf0a780ff5b60a7a6e43ea533'] = 'Devises des ventes : %s';
$_MODULE['<{statssales}prestashop>statssales_17833fb3783b26e0a9bc8b21ee85302a'] = 'Pourcentage de commandes par état.';


return $_MODULE;

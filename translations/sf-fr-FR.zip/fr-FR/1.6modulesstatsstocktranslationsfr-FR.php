<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsstock}prestashop>statsstock_96ca47f429c269b85e31be9fb17df6d4'] = 'Quantités disponibles';
$_MODULE['<{statsstock}prestashop>statsstock_7782fb19c81ec8a47e39f9c073b7da59'] = 'Ajoute un onglet indiquant la quantité de produits disponibles et en vente dans le tableau de bord des statistiques.';
$_MODULE['<{statsstock}prestashop>statsstock_c49b42f642c62f20a3640f20ca132840'] = 'Évaluation de la quantité disponible à la vente';
$_MODULE['<{statsstock}prestashop>statsstock_3adbdb3ac060038aa0e6e6c138ef9873'] = 'Catégorie';
$_MODULE['<{statsstock}prestashop>statsstock_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Toutes';
$_MODULE['<{statsstock}prestashop>statsstock_1b2379801de373b6b563c347014fb34b'] = 'Votre catalogue est vide.';
$_MODULE['<{statsstock}prestashop>statsstock_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statsstock}prestashop>statsstock_12d3c7a4296542c62474856ec452c045'] = 'Réf.';
$_MODULE['<{statsstock}prestashop>statsstock_7d74f3b92b19da5e606d737d339a9679'] = 'Article';
$_MODULE['<{statsstock}prestashop>statsstock_7bd5825a187064017975513b95d7f7de'] = 'Quantité disponible à la vente';
$_MODULE['<{statsstock}prestashop>statsstock_88940d60e75cf4ff38ce27db4efc83b2'] = 'Prix*';
$_MODULE['<{statsstock}prestashop>statsstock_689202409e48743b914713f96d93947c'] = 'Valeur';
$_MODULE['<{statsstock}prestashop>statsstock_347cbf03d737b02a70a96ff204c22fbc'] = 'Total des quantités';
$_MODULE['<{statsstock}prestashop>statsstock_844c29394eea07066bb2efefc35784ec'] = 'Prix moyen';
$_MODULE['<{statsstock}prestashop>statsstock_62668f75fc6977f3d09df632d1585d07'] = 'Valeur total';
$_MODULE['<{statsstock}prestashop>statsstock_a9873f90f06f9e2cfa3d048298ecca8c'] = 'Correspond au prix de vente par défaut selon le fournisseur par défaut du produit. Un prix moyen est utilisé quand le produit possède des déclinaisons.';


return $_MODULE;
